<?php

$unset_session_prop = function ($prop) {
   unset($_SESSION[$prop]);
};
