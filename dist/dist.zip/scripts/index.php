<?php
require_once './../php/orm.config.php';

$VER = time();
$ATTACH = './src/Attach';
$PHP = './php';
$ROOT = './src/Root';
$ASSETS = './src/Assets';
$MODE = 'dev';
?><?php
require_once __DIR__ . '/../php/JustField.php';
$db = new JustField\DB($orm);

function gen_from_get($prefix) { 
   return function (&$variable, $get_key, $is_echo = true) use ($prefix) { 
      if (isset($_GET[$get_key])) { 
         $variable = $_GET[$get_key]; 
      } else if ($is_echo) { 
         echo($prefix . ': ' . "no \"$get_key\" in \$_GET" . '<br>'); 
      } else { 
         $variable = null; 
      } 
   }; 
} 

function gen_from_post($prefix) { 
   return function (&$variable, $get_key, $is_echo = true) use ($prefix) { 
      if (isset($_POST[$get_key])) { 
         $variable = $_POST[$get_key]; 
      } else if ($is_echo) { 
         echo($prefix . ': ' . "no \"$get_key\" in \$_POST" . '<br>'); 
      } else { 
         $variable = null; 
      } 
   }; 
} 
?><?php
if (isset($_GET['script']) || isset($_POST['script'])):
   $script = isset($_GET['script']) ? $_GET['script'] : $_POST['script'];

   if ($script == 'exit'):
      session_start();
      unset($_SESSION['id']);
      session_destroy();

      header("Location: ./../login");
      die;


   elseif ($script == 'login'):
      if (isset($_POST['login']) && isset($_POST['password'])):
         session_start();

         $login = $_POST['login'];
         $password = $_POST['password'];

         $db->orm->is_log = false;
         $id = $db->orm->from('account')->select('id_account')->where("account_login = '$login' AND account_password = '$password'")();

         if (!$id):
            $_SESSION['login_error'] = 'uncorrect login or password';
            header('Location: ./../login/');
         
         else:
            $id = $id[0]['id_account'];
            $_SESSION['id'] = $id;

            unset($_SESSION['login_error']);
            header('Location: ./../main/');
         
         endif;

      else:
         echo('NO POST');

      endif;


   elseif ($script == 'field-add'):
      $from_get = gen_from_get('field-add');

      $from_get($field_type_id, 'type-id');
      $from_get($path, 'path');

      $db->orm->is_log = false;
      $new_field_id = $db->at_path($path)->add_field($field_type_id);

      echo '{ "status": "OK", "id": "'.$new_field_id.'}"}';


   elseif ($script == 'field-update'):
      $from_post = gen_from_post('field-update');

      $from_post($item_id, 'item_id');
      $from_post($colname, 'colname');
      $from_post($value, 'value', false);

      $db->orm->is_log = false;
      $res = $db->at_id($item_id)->update($colname, $value);

      echo '{ "status": "OK", "data": "'.$res.'" }';


   elseif ($script == 'field-delete'):
      $from_get = gen_from_get('field-delete');

      $from_get($item_id, 'item_id');

      $db->orm->is_log = false;
      $db->at_id($item_id)->remove();

      echo '{ "status": "OK" }';


   elseif ($script == 'field-duplicate'):
      $from_get = gen_from_get('field-duplicate');
   
      $from_get($item_id, 'item_id');

      $db->orm->is_log = false;
      $new_id = $db->at_id($item_id)->duplicate();

      echo '{ "status": "OK", "id": '.$new_id.' }';


   elseif ($script == 'info'):
      phpinfo();

   endif;


else:
   echo '{ "status": "ERR", "message": "Error: no or unexpected script in $_GET" }';

endif;?>